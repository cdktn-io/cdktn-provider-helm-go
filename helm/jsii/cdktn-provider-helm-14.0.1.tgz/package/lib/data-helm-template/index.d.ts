/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataHelmTemplateConfig extends cdktn.TerraformMetaArguments {
    /**
    * Kubernetes api versions used for Capabilities.APIVersions.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/helm/3.1.1/docs/data-sources/template#api_versions DataHelmTemplate#api_versions}
    */
    readonly apiVersions?: string[];
    /**
    * If set, the installation process purges the chart on fail. The 'wait' flag will be set automatically if 'atomic' is used.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/helm/3.1.1/docs/data-sources/template#atomic DataHelmTemplate#atomic}
    */
    readonly atomic?: boolean | cdktn.IResolvable;
    /**
    * Chart name to be installed. A path may be used.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/helm/3.1.1/docs/data-sources/template#chart DataHelmTemplate#chart}
    */
    readonly chart: string;
    /**
    * List of rendered CRDs from the chart.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/helm/3.1.1/docs/data-sources/template#crds DataHelmTemplate#crds}
    */
    readonly crds?: string[];
    /**
    * Create the namespace if it does not exist.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/helm/3.1.1/docs/data-sources/template#create_namespace DataHelmTemplate#create_namespace}
    */
    readonly createNamespace?: boolean | cdktn.IResolvable;
    /**
    * Run helm dependency update before installing the chart.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/helm/3.1.1/docs/data-sources/template#dependency_update DataHelmTemplate#dependency_update}
    */
    readonly dependencyUpdate?: boolean | cdktn.IResolvable;
    /**
    * Add a custom description.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/helm/3.1.1/docs/data-sources/template#description DataHelmTemplate#description}
    */
    readonly description?: string;
    /**
    * Use chart development versions, too. Equivalent to version '>0.0.0-0'. If `version` is set, this is ignored.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/helm/3.1.1/docs/data-sources/template#devel DataHelmTemplate#devel}
    */
    readonly devel?: boolean | cdktn.IResolvable;
    /**
    * If set, the installation process will not validate rendered templates against the Kubernetes OpenAPI Schema.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/helm/3.1.1/docs/data-sources/template#disable_openapi_validation DataHelmTemplate#disable_openapi_validation}
    */
    readonly disableOpenapiValidation?: boolean | cdktn.IResolvable;
    /**
    * Prevent hooks from running.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/helm/3.1.1/docs/data-sources/template#disable_webhooks DataHelmTemplate#disable_webhooks}
    */
    readonly disableWebhooks?: boolean | cdktn.IResolvable;
    /**
    * Include CRDs in the templated output.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/helm/3.1.1/docs/data-sources/template#include_crds DataHelmTemplate#include_crds}
    */
    readonly includeCrds?: boolean | cdktn.IResolvable;
    /**
    * Set .Release.IsUpgrade instead of .Release.IsInstall.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/helm/3.1.1/docs/data-sources/template#is_upgrade DataHelmTemplate#is_upgrade}
    */
    readonly isUpgrade?: boolean | cdktn.IResolvable;
    /**
    * Location of public keys used for verification. Used only if `verify` is true.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/helm/3.1.1/docs/data-sources/template#keyring DataHelmTemplate#keyring}
    */
    readonly keyring?: string;
    /**
    * Kubernetes version used for Capabilities.KubeVersion.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/helm/3.1.1/docs/data-sources/template#kube_version DataHelmTemplate#kube_version}
    */
    readonly kubeVersion?: string;
    /**
    * Concatenated rendered chart templates. This corresponds to the output of the `helm template` command.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/helm/3.1.1/docs/data-sources/template#manifest DataHelmTemplate#manifest}
    */
    readonly manifest?: string;
    /**
    * Map of rendered chart templates indexed by the template name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/helm/3.1.1/docs/data-sources/template#manifests DataHelmTemplate#manifests}
    */
    readonly manifests?: {
        [key: string]: string;
    };
    /**
    * Release name
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/helm/3.1.1/docs/data-sources/template#name DataHelmTemplate#name}
    */
    readonly name: string;
    /**
    * Namespace to install the release into.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/helm/3.1.1/docs/data-sources/template#namespace DataHelmTemplate#namespace}
    */
    readonly namespace?: string;
    /**
    * Rendered notes if the chart contains a `NOTES.txt`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/helm/3.1.1/docs/data-sources/template#notes DataHelmTemplate#notes}
    */
    readonly notes?: string;
    /**
    * Pass credentials to all domains
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/helm/3.1.1/docs/data-sources/template#pass_credentials DataHelmTemplate#pass_credentials}
    */
    readonly passCredentials?: boolean | cdktn.IResolvable;
    /**
    * Postrender command config
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/helm/3.1.1/docs/data-sources/template#postrender DataHelmTemplate#postrender}
    */
    readonly postrender?: DataHelmTemplatePostrender;
    /**
    * If set, render subchart notes along with the parent.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/helm/3.1.1/docs/data-sources/template#render_subchart_notes DataHelmTemplate#render_subchart_notes}
    */
    readonly renderSubchartNotes?: boolean | cdktn.IResolvable;
    /**
    * Re-use the given name, even if that name is already used. This is unsafe in production.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/helm/3.1.1/docs/data-sources/template#replace DataHelmTemplate#replace}
    */
    readonly replace?: boolean | cdktn.IResolvable;
    /**
    * Repository where to locate the requested chart. If it is a URL the chart is installed without installing the repository.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/helm/3.1.1/docs/data-sources/template#repository DataHelmTemplate#repository}
    */
    readonly repository?: string;
    /**
    * The repository's CA file
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/helm/3.1.1/docs/data-sources/template#repository_ca_file DataHelmTemplate#repository_ca_file}
    */
    readonly repositoryCaFile?: string;
    /**
    * The repository's cert file
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/helm/3.1.1/docs/data-sources/template#repository_cert_file DataHelmTemplate#repository_cert_file}
    */
    readonly repositoryCertFile?: string;
    /**
    * The repository's cert key file
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/helm/3.1.1/docs/data-sources/template#repository_key_file DataHelmTemplate#repository_key_file}
    */
    readonly repositoryKeyFile?: string;
    /**
    * Password for HTTP basic authentication
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/helm/3.1.1/docs/data-sources/template#repository_password DataHelmTemplate#repository_password}
    */
    readonly repositoryPassword?: string;
    /**
    * Username for HTTP basic authentication
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/helm/3.1.1/docs/data-sources/template#repository_username DataHelmTemplate#repository_username}
    */
    readonly repositoryUsername?: string;
    /**
    * When upgrading, reset the values to the ones built into the chart.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/helm/3.1.1/docs/data-sources/template#reset_values DataHelmTemplate#reset_values}
    */
    readonly resetValues?: boolean | cdktn.IResolvable;
    /**
    * When upgrading, reuse the last release's values and merge in any overrides. If 'reset_values' is specified, this is ignored.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/helm/3.1.1/docs/data-sources/template#reuse_values DataHelmTemplate#reuse_values}
    */
    readonly reuseValues?: boolean | cdktn.IResolvable;
    /**
    * Custom values to be merged with the values
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/helm/3.1.1/docs/data-sources/template#set DataHelmTemplate#set}
    */
    readonly set?: DataHelmTemplateSet[] | cdktn.IResolvable;
    /**
    * Custom sensitive values to be merged with the values
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/helm/3.1.1/docs/data-sources/template#set_list DataHelmTemplate#set_list}
    */
    readonly setList?: DataHelmTemplateSetListStruct[] | cdktn.IResolvable;
    /**
    * Custom sensitive values to be merged with the values
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/helm/3.1.1/docs/data-sources/template#set_sensitive DataHelmTemplate#set_sensitive}
    */
    readonly setSensitive?: DataHelmTemplateSetSensitive[] | cdktn.IResolvable;
    /**
    * Write-only custom values to be merged with the values.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/helm/3.1.1/docs/data-sources/template#set_wo DataHelmTemplate#set_wo}
    */
    readonly setWo?: DataHelmTemplateSetWo[] | cdktn.IResolvable;
    /**
    * Only show manifests rendered from the given templates.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/helm/3.1.1/docs/data-sources/template#show_only DataHelmTemplate#show_only}
    */
    readonly showOnly?: string[];
    /**
    * If set, no CRDs will be installed. By default, CRDs are installed if not already present.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/helm/3.1.1/docs/data-sources/template#skip_crds DataHelmTemplate#skip_crds}
    */
    readonly skipCrds?: boolean | cdktn.IResolvable;
    /**
    * If set, tests will not be rendered. By default, tests are rendered.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/helm/3.1.1/docs/data-sources/template#skip_tests DataHelmTemplate#skip_tests}
    */
    readonly skipTests?: boolean | cdktn.IResolvable;
    /**
    * Time in seconds to wait for any individual Kubernetes operation.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/helm/3.1.1/docs/data-sources/template#timeout DataHelmTemplate#timeout}
    */
    readonly timeout?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/helm/3.1.1/docs/data-sources/template#timeouts DataHelmTemplate#timeouts}
    */
    readonly timeouts?: DataHelmTemplateTimeouts;
    /**
    * Validate your manifests against the Kubernetes cluster you are currently pointing at. This is the same validation performed on an install.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/helm/3.1.1/docs/data-sources/template#validate DataHelmTemplate#validate}
    */
    readonly validate?: boolean | cdktn.IResolvable;
    /**
    * List of values in raw yaml format to pass to helm.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/helm/3.1.1/docs/data-sources/template#values DataHelmTemplate#values}
    */
    readonly values?: string[];
    /**
    * Verify the package before installing it.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/helm/3.1.1/docs/data-sources/template#verify DataHelmTemplate#verify}
    */
    readonly verify?: boolean | cdktn.IResolvable;
    /**
    * Specify the exact chart version to install. If this is not specified, the latest version is installed.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/helm/3.1.1/docs/data-sources/template#version DataHelmTemplate#version}
    */
    readonly version?: string;
    /**
    * Will wait until all resources are in a ready state before marking the release as successful.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/helm/3.1.1/docs/data-sources/template#wait DataHelmTemplate#wait}
    */
    readonly wait?: boolean | cdktn.IResolvable;
}
export interface DataHelmTemplatePostrender {
    /**
    * An argument to the post-renderer (can specify multiple)
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/helm/3.1.1/docs/data-sources/template#args DataHelmTemplate#args}
    */
    readonly args?: string[];
    /**
    * The common binary path
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/helm/3.1.1/docs/data-sources/template#binary_path DataHelmTemplate#binary_path}
    */
    readonly binaryPath: string;
}
export declare function dataHelmTemplatePostrenderToTerraform(struct?: DataHelmTemplatePostrender | cdktn.IResolvable): any;
export declare function dataHelmTemplatePostrenderToHclTerraform(struct?: DataHelmTemplatePostrender | cdktn.IResolvable): any;
export declare class DataHelmTemplatePostrenderOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataHelmTemplatePostrender | cdktn.IResolvable | undefined;
    set internalValue(value: DataHelmTemplatePostrender | cdktn.IResolvable | undefined);
    private _args?;
    get args(): string[];
    set args(value: string[]);
    resetArgs(): void;
    get argsInput(): string[] | undefined;
    private _binaryPath?;
    get binaryPath(): string;
    set binaryPath(value: string);
    get binaryPathInput(): string | undefined;
}
export interface DataHelmTemplateSet {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/helm/3.1.1/docs/data-sources/template#name DataHelmTemplate#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/helm/3.1.1/docs/data-sources/template#type DataHelmTemplate#type}
    */
    readonly type?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/helm/3.1.1/docs/data-sources/template#value DataHelmTemplate#value}
    */
    readonly value?: string;
}
export declare function dataHelmTemplateSetToTerraform(struct?: DataHelmTemplateSet | cdktn.IResolvable): any;
export declare function dataHelmTemplateSetToHclTerraform(struct?: DataHelmTemplateSet | cdktn.IResolvable): any;
export declare class DataHelmTemplateSetOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataHelmTemplateSet | cdktn.IResolvable | undefined;
    set internalValue(value: DataHelmTemplateSet | cdktn.IResolvable | undefined);
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    resetType(): void;
    get typeInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export declare class DataHelmTemplateSetList extends cdktn.ComplexList {
    internalValue?: DataHelmTemplateSet[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataHelmTemplateSetOutputReference;
}
export interface DataHelmTemplateSetListStruct {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/helm/3.1.1/docs/data-sources/template#name DataHelmTemplate#name}
    */
    readonly name?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/helm/3.1.1/docs/data-sources/template#value DataHelmTemplate#value}
    */
    readonly value: string[];
}
export declare function dataHelmTemplateSetListStructToTerraform(struct?: DataHelmTemplateSetListStruct | cdktn.IResolvable): any;
export declare function dataHelmTemplateSetListStructToHclTerraform(struct?: DataHelmTemplateSetListStruct | cdktn.IResolvable): any;
export declare class DataHelmTemplateSetListStructOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataHelmTemplateSetListStruct | cdktn.IResolvable | undefined;
    set internalValue(value: DataHelmTemplateSetListStruct | cdktn.IResolvable | undefined);
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _value?;
    get value(): string[];
    set value(value: string[]);
    get valueInput(): string[] | undefined;
}
export declare class DataHelmTemplateSetListStructList extends cdktn.ComplexList {
    internalValue?: DataHelmTemplateSetListStruct[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataHelmTemplateSetListStructOutputReference;
}
export interface DataHelmTemplateSetSensitive {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/helm/3.1.1/docs/data-sources/template#name DataHelmTemplate#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/helm/3.1.1/docs/data-sources/template#type DataHelmTemplate#type}
    */
    readonly type?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/helm/3.1.1/docs/data-sources/template#value DataHelmTemplate#value}
    */
    readonly value: string;
}
export declare function dataHelmTemplateSetSensitiveToTerraform(struct?: DataHelmTemplateSetSensitive | cdktn.IResolvable): any;
export declare function dataHelmTemplateSetSensitiveToHclTerraform(struct?: DataHelmTemplateSetSensitive | cdktn.IResolvable): any;
export declare class DataHelmTemplateSetSensitiveOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataHelmTemplateSetSensitive | cdktn.IResolvable | undefined;
    set internalValue(value: DataHelmTemplateSetSensitive | cdktn.IResolvable | undefined);
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    resetType(): void;
    get typeInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    get valueInput(): string | undefined;
}
export declare class DataHelmTemplateSetSensitiveList extends cdktn.ComplexList {
    internalValue?: DataHelmTemplateSetSensitive[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataHelmTemplateSetSensitiveOutputReference;
}
export interface DataHelmTemplateSetWo {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/helm/3.1.1/docs/data-sources/template#name DataHelmTemplate#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/helm/3.1.1/docs/data-sources/template#type DataHelmTemplate#type}
    */
    readonly type?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/helm/3.1.1/docs/data-sources/template#value DataHelmTemplate#value}
    */
    readonly value: string;
}
export declare function dataHelmTemplateSetWoToTerraform(struct?: DataHelmTemplateSetWo | cdktn.IResolvable): any;
export declare function dataHelmTemplateSetWoToHclTerraform(struct?: DataHelmTemplateSetWo | cdktn.IResolvable): any;
export declare class DataHelmTemplateSetWoOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataHelmTemplateSetWo | cdktn.IResolvable | undefined;
    set internalValue(value: DataHelmTemplateSetWo | cdktn.IResolvable | undefined);
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    resetType(): void;
    get typeInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    get valueInput(): string | undefined;
}
export declare class DataHelmTemplateSetWoList extends cdktn.ComplexList {
    internalValue?: DataHelmTemplateSetWo[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataHelmTemplateSetWoOutputReference;
}
export interface DataHelmTemplateTimeouts {
    /**
    * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/helm/3.1.1/docs/data-sources/template#read DataHelmTemplate#read}
    */
    readonly read?: string;
}
export declare function dataHelmTemplateTimeoutsToTerraform(struct?: DataHelmTemplateTimeouts | cdktn.IResolvable): any;
export declare function dataHelmTemplateTimeoutsToHclTerraform(struct?: DataHelmTemplateTimeouts | cdktn.IResolvable): any;
export declare class DataHelmTemplateTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataHelmTemplateTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: DataHelmTemplateTimeouts | cdktn.IResolvable | undefined);
    private _read?;
    get read(): string;
    set read(value: string);
    resetRead(): void;
    get readInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/helm/3.1.1/docs/data-sources/template helm_template}
*/
export declare class DataHelmTemplate extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "helm_template";
    /**
    * Generates CDKTN code for importing a DataHelmTemplate resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataHelmTemplate to import
    * @param importFromId The id of the existing DataHelmTemplate that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/helm/3.1.1/docs/data-sources/template#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataHelmTemplate to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/helm/3.1.1/docs/data-sources/template helm_template} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataHelmTemplateConfig
    */
    constructor(scope: Construct, id: string, config: DataHelmTemplateConfig);
    private _apiVersions?;
    get apiVersions(): string[];
    set apiVersions(value: string[]);
    resetApiVersions(): void;
    get apiVersionsInput(): string[] | undefined;
    private _atomic?;
    get atomic(): boolean | cdktn.IResolvable;
    set atomic(value: boolean | cdktn.IResolvable);
    resetAtomic(): void;
    get atomicInput(): boolean | cdktn.IResolvable | undefined;
    private _chart?;
    get chart(): string;
    set chart(value: string);
    get chartInput(): string | undefined;
    private _crds?;
    get crds(): string[];
    set crds(value: string[]);
    resetCrds(): void;
    get crdsInput(): string[] | undefined;
    private _createNamespace?;
    get createNamespace(): boolean | cdktn.IResolvable;
    set createNamespace(value: boolean | cdktn.IResolvable);
    resetCreateNamespace(): void;
    get createNamespaceInput(): boolean | cdktn.IResolvable | undefined;
    private _dependencyUpdate?;
    get dependencyUpdate(): boolean | cdktn.IResolvable;
    set dependencyUpdate(value: boolean | cdktn.IResolvable);
    resetDependencyUpdate(): void;
    get dependencyUpdateInput(): boolean | cdktn.IResolvable | undefined;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _devel?;
    get devel(): boolean | cdktn.IResolvable;
    set devel(value: boolean | cdktn.IResolvable);
    resetDevel(): void;
    get develInput(): boolean | cdktn.IResolvable | undefined;
    private _disableOpenapiValidation?;
    get disableOpenapiValidation(): boolean | cdktn.IResolvable;
    set disableOpenapiValidation(value: boolean | cdktn.IResolvable);
    resetDisableOpenapiValidation(): void;
    get disableOpenapiValidationInput(): boolean | cdktn.IResolvable | undefined;
    private _disableWebhooks?;
    get disableWebhooks(): boolean | cdktn.IResolvable;
    set disableWebhooks(value: boolean | cdktn.IResolvable);
    resetDisableWebhooks(): void;
    get disableWebhooksInput(): boolean | cdktn.IResolvable | undefined;
    get id(): string;
    private _includeCrds?;
    get includeCrds(): boolean | cdktn.IResolvable;
    set includeCrds(value: boolean | cdktn.IResolvable);
    resetIncludeCrds(): void;
    get includeCrdsInput(): boolean | cdktn.IResolvable | undefined;
    private _isUpgrade?;
    get isUpgrade(): boolean | cdktn.IResolvable;
    set isUpgrade(value: boolean | cdktn.IResolvable);
    resetIsUpgrade(): void;
    get isUpgradeInput(): boolean | cdktn.IResolvable | undefined;
    private _keyring?;
    get keyring(): string;
    set keyring(value: string);
    resetKeyring(): void;
    get keyringInput(): string | undefined;
    private _kubeVersion?;
    get kubeVersion(): string;
    set kubeVersion(value: string);
    resetKubeVersion(): void;
    get kubeVersionInput(): string | undefined;
    private _manifest?;
    get manifest(): string;
    set manifest(value: string);
    resetManifest(): void;
    get manifestInput(): string | undefined;
    private _manifests?;
    get manifests(): {
        [key: string]: string;
    };
    set manifests(value: {
        [key: string]: string;
    });
    resetManifests(): void;
    get manifestsInput(): {
        [key: string]: string;
    } | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _namespace?;
    get namespace(): string;
    set namespace(value: string);
    resetNamespace(): void;
    get namespaceInput(): string | undefined;
    private _notes?;
    get notes(): string;
    set notes(value: string);
    resetNotes(): void;
    get notesInput(): string | undefined;
    private _passCredentials?;
    get passCredentials(): boolean | cdktn.IResolvable;
    set passCredentials(value: boolean | cdktn.IResolvable);
    resetPassCredentials(): void;
    get passCredentialsInput(): boolean | cdktn.IResolvable | undefined;
    private _postrender;
    get postrender(): DataHelmTemplatePostrenderOutputReference;
    putPostrender(value: DataHelmTemplatePostrender): void;
    resetPostrender(): void;
    get postrenderInput(): cdktn.IResolvable | DataHelmTemplatePostrender | undefined;
    private _renderSubchartNotes?;
    get renderSubchartNotes(): boolean | cdktn.IResolvable;
    set renderSubchartNotes(value: boolean | cdktn.IResolvable);
    resetRenderSubchartNotes(): void;
    get renderSubchartNotesInput(): boolean | cdktn.IResolvable | undefined;
    private _replace?;
    get replace(): boolean | cdktn.IResolvable;
    set replace(value: boolean | cdktn.IResolvable);
    resetReplace(): void;
    get replaceInput(): boolean | cdktn.IResolvable | undefined;
    private _repository?;
    get repository(): string;
    set repository(value: string);
    resetRepository(): void;
    get repositoryInput(): string | undefined;
    private _repositoryCaFile?;
    get repositoryCaFile(): string;
    set repositoryCaFile(value: string);
    resetRepositoryCaFile(): void;
    get repositoryCaFileInput(): string | undefined;
    private _repositoryCertFile?;
    get repositoryCertFile(): string;
    set repositoryCertFile(value: string);
    resetRepositoryCertFile(): void;
    get repositoryCertFileInput(): string | undefined;
    private _repositoryKeyFile?;
    get repositoryKeyFile(): string;
    set repositoryKeyFile(value: string);
    resetRepositoryKeyFile(): void;
    get repositoryKeyFileInput(): string | undefined;
    private _repositoryPassword?;
    get repositoryPassword(): string;
    set repositoryPassword(value: string);
    resetRepositoryPassword(): void;
    get repositoryPasswordInput(): string | undefined;
    private _repositoryUsername?;
    get repositoryUsername(): string;
    set repositoryUsername(value: string);
    resetRepositoryUsername(): void;
    get repositoryUsernameInput(): string | undefined;
    private _resetValues?;
    get resetValues(): boolean | cdktn.IResolvable;
    set resetValues(value: boolean | cdktn.IResolvable);
    resetResetValues(): void;
    get resetValuesInput(): boolean | cdktn.IResolvable | undefined;
    private _reuseValues?;
    get reuseValues(): boolean | cdktn.IResolvable;
    set reuseValues(value: boolean | cdktn.IResolvable);
    resetReuseValues(): void;
    get reuseValuesInput(): boolean | cdktn.IResolvable | undefined;
    private _set;
    get set(): DataHelmTemplateSetList;
    putSet(value: DataHelmTemplateSet[] | cdktn.IResolvable): void;
    resetSet(): void;
    get setInput(): cdktn.IResolvable | DataHelmTemplateSet[] | undefined;
    private _setList;
    get setList(): DataHelmTemplateSetListStructList;
    putSetList(value: DataHelmTemplateSetListStruct[] | cdktn.IResolvable): void;
    resetSetList(): void;
    get setListInput(): cdktn.IResolvable | DataHelmTemplateSetListStruct[] | undefined;
    private _setSensitive;
    get setSensitive(): DataHelmTemplateSetSensitiveList;
    putSetSensitive(value: DataHelmTemplateSetSensitive[] | cdktn.IResolvable): void;
    resetSetSensitive(): void;
    get setSensitiveInput(): cdktn.IResolvable | DataHelmTemplateSetSensitive[] | undefined;
    private _setWo;
    get setWo(): DataHelmTemplateSetWoList;
    putSetWo(value: DataHelmTemplateSetWo[] | cdktn.IResolvable): void;
    resetSetWo(): void;
    get setWoInput(): cdktn.IResolvable | DataHelmTemplateSetWo[] | undefined;
    private _showOnly?;
    get showOnly(): string[];
    set showOnly(value: string[]);
    resetShowOnly(): void;
    get showOnlyInput(): string[] | undefined;
    private _skipCrds?;
    get skipCrds(): boolean | cdktn.IResolvable;
    set skipCrds(value: boolean | cdktn.IResolvable);
    resetSkipCrds(): void;
    get skipCrdsInput(): boolean | cdktn.IResolvable | undefined;
    private _skipTests?;
    get skipTests(): boolean | cdktn.IResolvable;
    set skipTests(value: boolean | cdktn.IResolvable);
    resetSkipTests(): void;
    get skipTestsInput(): boolean | cdktn.IResolvable | undefined;
    private _timeout?;
    get timeout(): number;
    set timeout(value: number);
    resetTimeout(): void;
    get timeoutInput(): number | undefined;
    private _timeouts;
    get timeouts(): DataHelmTemplateTimeoutsOutputReference;
    putTimeouts(value: DataHelmTemplateTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | DataHelmTemplateTimeouts | undefined;
    private _validate?;
    get validate(): boolean | cdktn.IResolvable;
    set validate(value: boolean | cdktn.IResolvable);
    resetValidate(): void;
    get validateInput(): boolean | cdktn.IResolvable | undefined;
    private _values?;
    get values(): string[];
    set values(value: string[]);
    resetTfValues(): void;
    get valuesInput(): string[] | undefined;
    private _verify?;
    get verify(): boolean | cdktn.IResolvable;
    set verify(value: boolean | cdktn.IResolvable);
    resetVerify(): void;
    get verifyInput(): boolean | cdktn.IResolvable | undefined;
    private _version?;
    get version(): string;
    set version(value: string);
    resetVersion(): void;
    get versionInput(): string | undefined;
    private _wait?;
    get wait(): boolean | cdktn.IResolvable;
    set wait(value: boolean | cdktn.IResolvable);
    resetWait(): void;
    get waitInput(): boolean | cdktn.IResolvable | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
