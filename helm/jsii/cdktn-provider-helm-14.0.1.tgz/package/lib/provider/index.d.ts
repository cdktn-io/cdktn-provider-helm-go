/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface HelmProviderConfig {
    /**
    * Helm burst limit. Increase this if you have a cluster with many CRDs
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/helm/3.1.1/docs#burst_limit HelmProvider#burst_limit}
    */
    readonly burstLimit?: number;
    /**
    * Debug indicates whether or not Helm is running in Debug mode.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/helm/3.1.1/docs#debug HelmProvider#debug}
    */
    readonly debug?: boolean | cdktn.IResolvable;
    /**
    * Enable and disable experimental features.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/helm/3.1.1/docs#experiments HelmProvider#experiments}
    */
    readonly experiments?: HelmProviderExperiments;
    /**
    * The backend storage driver. Values are: configmap, secret, memory, sql
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/helm/3.1.1/docs#helm_driver HelmProvider#helm_driver}
    */
    readonly helmDriver?: string;
    /**
    * Kubernetes Configuration
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/helm/3.1.1/docs#kubernetes HelmProvider#kubernetes}
    */
    readonly kubernetes?: HelmProviderKubernetes;
    /**
    * The path to the helm plugins directory
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/helm/3.1.1/docs#plugins_path HelmProvider#plugins_path}
    */
    readonly pluginsPath?: string;
    /**
    * Queries per second used when communicating with the Kubernetes API. Can be used to avoid throttling.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/helm/3.1.1/docs#qps HelmProvider#qps}
    */
    readonly qps?: number;
    /**
    * RegistryClient configuration.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/helm/3.1.1/docs#registries HelmProvider#registries}
    */
    readonly registries?: HelmProviderRegistries[] | cdktn.IResolvable;
    /**
    * The path to the registry config file
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/helm/3.1.1/docs#registry_config_path HelmProvider#registry_config_path}
    */
    readonly registryConfigPath?: string;
    /**
    * The path to the file containing cached repository indexes
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/helm/3.1.1/docs#repository_cache HelmProvider#repository_cache}
    */
    readonly repositoryCache?: string;
    /**
    * The path to the file containing repository names and URLs
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/helm/3.1.1/docs#repository_config_path HelmProvider#repository_config_path}
    */
    readonly repositoryConfigPath?: string;
    /**
    * Alias name
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/helm/3.1.1/docs#alias HelmProvider#alias}
    */
    readonly alias?: string;
}
export interface HelmProviderExperiments {
    /**
    * Enable full diff by storing the rendered manifest in the state.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/helm/3.1.1/docs#manifest HelmProvider#manifest}
    */
    readonly manifest?: boolean | cdktn.IResolvable;
}
export declare function helmProviderExperimentsToTerraform(struct?: HelmProviderExperiments | cdktn.IResolvable): any;
export declare function helmProviderExperimentsToHclTerraform(struct?: HelmProviderExperiments | cdktn.IResolvable): any;
export interface HelmProviderKubernetesExec {
    /**
    * API version for the exec plugin.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/helm/3.1.1/docs#api_version HelmProvider#api_version}
    */
    readonly apiVersion: string;
    /**
    * Arguments for the exec plugin
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/helm/3.1.1/docs#args HelmProvider#args}
    */
    readonly args?: string[];
    /**
    * Command to run for Kubernetes exec plugin
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/helm/3.1.1/docs#command HelmProvider#command}
    */
    readonly command: string;
    /**
    * Environment variables for the exec plugin
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/helm/3.1.1/docs#env HelmProvider#env}
    */
    readonly env?: {
        [key: string]: string;
    };
}
export declare function helmProviderKubernetesExecToTerraform(struct?: HelmProviderKubernetesExec | cdktn.IResolvable): any;
export declare function helmProviderKubernetesExecToHclTerraform(struct?: HelmProviderKubernetesExec | cdktn.IResolvable): any;
export interface HelmProviderKubernetes {
    /**
    * PEM-encoded client certificate for TLS authentication.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/helm/3.1.1/docs#client_certificate HelmProvider#client_certificate}
    */
    readonly clientCertificate?: string;
    /**
    * PEM-encoded client certificate key for TLS authentication.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/helm/3.1.1/docs#client_key HelmProvider#client_key}
    */
    readonly clientKey?: string;
    /**
    * PEM-encoded root certificates bundle for TLS authentication.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/helm/3.1.1/docs#cluster_ca_certificate HelmProvider#cluster_ca_certificate}
    */
    readonly clusterCaCertificate?: string;
    /**
    * Context to choose from the config file. Can be sourced from KUBE_CTX.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/helm/3.1.1/docs#config_context HelmProvider#config_context}
    */
    readonly configContext?: string;
    /**
    * Authentication info context of the kube config (name of the kubeconfig user, --user flag in kubectl). Can be sourced from KUBE_CTX_AUTH_INFO.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/helm/3.1.1/docs#config_context_auth_info HelmProvider#config_context_auth_info}
    */
    readonly configContextAuthInfo?: string;
    /**
    * Cluster context of the kube config (name of the kubeconfig cluster, --cluster flag in kubectl). Can be sourced from KUBE_CTX_CLUSTER.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/helm/3.1.1/docs#config_context_cluster HelmProvider#config_context_cluster}
    */
    readonly configContextCluster?: string;
    /**
    * Path to the kube config file. Can be set with KUBE_CONFIG_PATH.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/helm/3.1.1/docs#config_path HelmProvider#config_path}
    */
    readonly configPath?: string;
    /**
    * A list of paths to kube config files. Can be set with KUBE_CONFIG_PATHS environment variable.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/helm/3.1.1/docs#config_paths HelmProvider#config_paths}
    */
    readonly configPaths?: string[];
    /**
    * Exec configuration for Kubernetes authentication
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/helm/3.1.1/docs#exec HelmProvider#exec}
    */
    readonly exec?: HelmProviderKubernetesExec;
    /**
    * The hostname (in form of URI) of kubernetes master
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/helm/3.1.1/docs#host HelmProvider#host}
    */
    readonly host?: string;
    /**
    * Whether server should be accessed without verifying the TLS certificate.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/helm/3.1.1/docs#insecure HelmProvider#insecure}
    */
    readonly insecure?: boolean | cdktn.IResolvable;
    /**
    * The password to use for HTTP basic authentication when accessing the Kubernetes master endpoint.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/helm/3.1.1/docs#password HelmProvider#password}
    */
    readonly password?: string;
    /**
    * URL to the proxy to be used for all API requests.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/helm/3.1.1/docs#proxy_url HelmProvider#proxy_url}
    */
    readonly proxyUrl?: string;
    /**
    * Server name passed to the server for SNI and is used in the client to check server certificates against.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/helm/3.1.1/docs#tls_server_name HelmProvider#tls_server_name}
    */
    readonly tlsServerName?: string;
    /**
    * Token to authenticate a service account.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/helm/3.1.1/docs#token HelmProvider#token}
    */
    readonly token?: string;
    /**
    * The username to use for HTTP basic authentication when accessing the Kubernetes master endpoint
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/helm/3.1.1/docs#username HelmProvider#username}
    */
    readonly username?: string;
}
export declare function helmProviderKubernetesToTerraform(struct?: HelmProviderKubernetes | cdktn.IResolvable): any;
export declare function helmProviderKubernetesToHclTerraform(struct?: HelmProviderKubernetes | cdktn.IResolvable): any;
export interface HelmProviderRegistries {
    /**
    * The password to use for the OCI HTTP basic authentication when accessing the Kubernetes master endpoint.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/helm/3.1.1/docs#password HelmProvider#password}
    */
    readonly password: string;
    /**
    * OCI URL in form of oci://host:port or oci://host
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/helm/3.1.1/docs#url HelmProvider#url}
    */
    readonly url: string;
    /**
    * The username to use for the OCI HTTP basic authentication when accessing the Kubernetes master endpoint.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/helm/3.1.1/docs#username HelmProvider#username}
    */
    readonly username: string;
}
export declare function helmProviderRegistriesToTerraform(struct?: HelmProviderRegistries | cdktn.IResolvable): any;
export declare function helmProviderRegistriesToHclTerraform(struct?: HelmProviderRegistries | cdktn.IResolvable): any;
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/helm/3.1.1/docs helm}
*/
export declare class HelmProvider extends cdktn.TerraformProvider {
    static readonly tfResourceType = "helm";
    /**
    * Generates CDKTN code for importing a HelmProvider resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the HelmProvider to import
    * @param importFromId The id of the existing HelmProvider that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/helm/3.1.1/docs#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the HelmProvider to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/helm/3.1.1/docs helm} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options HelmProviderConfig = {}
    */
    constructor(scope: Construct, id: string, config?: HelmProviderConfig);
    private _burstLimit?;
    get burstLimit(): number | undefined;
    set burstLimit(value: number | undefined);
    resetBurstLimit(): void;
    get burstLimitInput(): number | undefined;
    private _debug?;
    get debug(): boolean | cdktn.IResolvable | undefined;
    set debug(value: boolean | cdktn.IResolvable | undefined);
    resetDebug(): void;
    get debugInput(): boolean | cdktn.IResolvable | undefined;
    private _experiments?;
    get experiments(): HelmProviderExperiments | undefined;
    set experiments(value: HelmProviderExperiments | undefined);
    resetExperiments(): void;
    get experimentsInput(): HelmProviderExperiments | undefined;
    private _helmDriver?;
    get helmDriver(): string | undefined;
    set helmDriver(value: string | undefined);
    resetHelmDriver(): void;
    get helmDriverInput(): string | undefined;
    private _kubernetes?;
    get kubernetes(): HelmProviderKubernetes | undefined;
    set kubernetes(value: HelmProviderKubernetes | undefined);
    resetKubernetes(): void;
    get kubernetesInput(): HelmProviderKubernetes | undefined;
    private _pluginsPath?;
    get pluginsPath(): string | undefined;
    set pluginsPath(value: string | undefined);
    resetPluginsPath(): void;
    get pluginsPathInput(): string | undefined;
    private _qps?;
    get qps(): number | undefined;
    set qps(value: number | undefined);
    resetQps(): void;
    get qpsInput(): number | undefined;
    private _registries?;
    get registries(): HelmProviderRegistries[] | cdktn.IResolvable | undefined;
    set registries(value: HelmProviderRegistries[] | cdktn.IResolvable | undefined);
    resetRegistries(): void;
    get registriesInput(): cdktn.IResolvable | HelmProviderRegistries[] | undefined;
    private _registryConfigPath?;
    get registryConfigPath(): string | undefined;
    set registryConfigPath(value: string | undefined);
    resetRegistryConfigPath(): void;
    get registryConfigPathInput(): string | undefined;
    private _repositoryCache?;
    get repositoryCache(): string | undefined;
    set repositoryCache(value: string | undefined);
    resetRepositoryCache(): void;
    get repositoryCacheInput(): string | undefined;
    private _repositoryConfigPath?;
    get repositoryConfigPath(): string | undefined;
    set repositoryConfigPath(value: string | undefined);
    resetRepositoryConfigPath(): void;
    get repositoryConfigPathInput(): string | undefined;
    private _alias?;
    get alias(): string | undefined;
    set alias(value: string | undefined);
    resetAlias(): void;
    get aliasInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
