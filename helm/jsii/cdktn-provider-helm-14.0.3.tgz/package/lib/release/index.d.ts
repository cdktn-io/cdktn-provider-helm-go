/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface ReleaseConfig extends cdktn.TerraformMetaArguments {
    /**
    * If set, installation process purges chart on fail. The wait flag will be set automatically if atomic is used
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/helm/3.1.2/docs/resources/release#atomic Release#atomic}
    */
    readonly atomic?: boolean | cdktn.IResolvable;
    /**
    * Chart name to be installed. A path may be used
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/helm/3.1.2/docs/resources/release#chart Release#chart}
    */
    readonly chart: string;
    /**
    * Allow deletion of new resources created in this upgrade when upgrade fails
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/helm/3.1.2/docs/resources/release#cleanup_on_fail Release#cleanup_on_fail}
    */
    readonly cleanupOnFail?: boolean | cdktn.IResolvable;
    /**
    * Create the namespace if it does not exist
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/helm/3.1.2/docs/resources/release#create_namespace Release#create_namespace}
    */
    readonly createNamespace?: boolean | cdktn.IResolvable;
    /**
    * Run helm dependency update before installing the chart
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/helm/3.1.2/docs/resources/release#dependency_update Release#dependency_update}
    */
    readonly dependencyUpdate?: boolean | cdktn.IResolvable;
    /**
    * Add a custom description
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/helm/3.1.2/docs/resources/release#description Release#description}
    */
    readonly description?: string;
    /**
    * Use chart development versions, too. Equivalent to version '>0.0.0-0'. If 'version' is set, this is ignored
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/helm/3.1.2/docs/resources/release#devel Release#devel}
    */
    readonly devel?: boolean | cdktn.IResolvable;
    /**
    * Prevent CRD hooks from running, but run other hooks. See helm install --no-crd-hook
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/helm/3.1.2/docs/resources/release#disable_crd_hooks Release#disable_crd_hooks}
    */
    readonly disableCrdHooks?: boolean | cdktn.IResolvable;
    /**
    * If set, the installation process will not validate rendered templates against the Kubernetes OpenAPI Schema
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/helm/3.1.2/docs/resources/release#disable_openapi_validation Release#disable_openapi_validation}
    */
    readonly disableOpenapiValidation?: boolean | cdktn.IResolvable;
    /**
    * Prevent hooks from running
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/helm/3.1.2/docs/resources/release#disable_webhooks Release#disable_webhooks}
    */
    readonly disableWebhooks?: boolean | cdktn.IResolvable;
    /**
    * Force resource update through delete/recreate if needed.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/helm/3.1.2/docs/resources/release#force_update Release#force_update}
    */
    readonly forceUpdate?: boolean | cdktn.IResolvable;
    /**
    * Location of public keys used for verification, Used only if 'verify is true'
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/helm/3.1.2/docs/resources/release#keyring Release#keyring}
    */
    readonly keyring?: string;
    /**
    * Run helm lint when planning
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/helm/3.1.2/docs/resources/release#lint Release#lint}
    */
    readonly lint?: boolean | cdktn.IResolvable;
    /**
    * Limit the maximum number of revisions saved per release. Use 0 for no limit
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/helm/3.1.2/docs/resources/release#max_history Release#max_history}
    */
    readonly maxHistory?: number;
    /**
    * Release name. The length must not be longer than 53 characters
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/helm/3.1.2/docs/resources/release#name Release#name}
    */
    readonly name: string;
    /**
    * Namespace to install the release into
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/helm/3.1.2/docs/resources/release#namespace Release#namespace}
    */
    readonly namespace?: string;
    /**
    * Pass credentials to all domains
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/helm/3.1.2/docs/resources/release#pass_credentials Release#pass_credentials}
    */
    readonly passCredentials?: boolean | cdktn.IResolvable;
    /**
    * Postrender command config
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/helm/3.1.2/docs/resources/release#postrender Release#postrender}
    */
    readonly postrender?: ReleasePostrender;
    /**
    * Perform pods restart during upgrade/rollback
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/helm/3.1.2/docs/resources/release#recreate_pods Release#recreate_pods}
    */
    readonly recreatePods?: boolean | cdktn.IResolvable;
    /**
    * If set, render subchart notes along with the parent
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/helm/3.1.2/docs/resources/release#render_subchart_notes Release#render_subchart_notes}
    */
    readonly renderSubchartNotes?: boolean | cdktn.IResolvable;
    /**
    * Re-use the given name, even if that name is already used. This is unsafe in production
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/helm/3.1.2/docs/resources/release#replace Release#replace}
    */
    readonly replace?: boolean | cdktn.IResolvable;
    /**
    * Repository where to locate the requested chart. If it is a URL, the chart is installed without installing the repository
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/helm/3.1.2/docs/resources/release#repository Release#repository}
    */
    readonly repository?: string;
    /**
    * The Repositories CA file
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/helm/3.1.2/docs/resources/release#repository_ca_file Release#repository_ca_file}
    */
    readonly repositoryCaFile?: string;
    /**
    * The repositories cert file
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/helm/3.1.2/docs/resources/release#repository_cert_file Release#repository_cert_file}
    */
    readonly repositoryCertFile?: string;
    /**
    * The repositories cert key file
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/helm/3.1.2/docs/resources/release#repository_key_file Release#repository_key_file}
    */
    readonly repositoryKeyFile?: string;
    /**
    * Password for HTTP basic authentication
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/helm/3.1.2/docs/resources/release#repository_password Release#repository_password}
    */
    readonly repositoryPassword?: string;
    /**
    * Username for HTTP basic authentication
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/helm/3.1.2/docs/resources/release#repository_username Release#repository_username}
    */
    readonly repositoryUsername?: string;
    /**
    * When upgrading, reset the values to the ones built into the chart
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/helm/3.1.2/docs/resources/release#reset_values Release#reset_values}
    */
    readonly resetValues?: boolean | cdktn.IResolvable;
    /**
    * When upgrading, reuse the last release's values and merge in any overrides. If 'reset_values' is specified, this is ignored
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/helm/3.1.2/docs/resources/release#reuse_values Release#reuse_values}
    */
    readonly reuseValues?: boolean | cdktn.IResolvable;
    /**
    * Custom values to be merged with the values
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/helm/3.1.2/docs/resources/release#set Release#set}
    */
    readonly set?: ReleaseSet[] | cdktn.IResolvable;
    /**
    * Custom sensitive values to be merged with the values
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/helm/3.1.2/docs/resources/release#set_list Release#set_list}
    */
    readonly setList?: ReleaseSetListStruct[] | cdktn.IResolvable;
    /**
    * Custom sensitive values to be merged with the values
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/helm/3.1.2/docs/resources/release#set_sensitive Release#set_sensitive}
    */
    readonly setSensitive?: ReleaseSetSensitive[] | cdktn.IResolvable;
    /**
    * Custom values to be merged with the values
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/helm/3.1.2/docs/resources/release#set_wo Release#set_wo}
    */
    readonly setWo?: ReleaseSetWo[] | cdktn.IResolvable;
    /**
    * The current revision of the write-only "set_wo" attribute. Incrementing this integer value will cause Terraform to update the write-only value.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/helm/3.1.2/docs/resources/release#set_wo_revision Release#set_wo_revision}
    */
    readonly setWoRevision?: number;
    /**
    * If set, no CRDs will be installed. By default, CRDs are installed if not already present
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/helm/3.1.2/docs/resources/release#skip_crds Release#skip_crds}
    */
    readonly skipCrds?: boolean | cdktn.IResolvable;
    /**
    * If set, Helm will take ownership of resources not already annotated by this release. Useful for migrations or recovery.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/helm/3.1.2/docs/resources/release#take_ownership Release#take_ownership}
    */
    readonly takeOwnership?: boolean | cdktn.IResolvable;
    /**
    * Time in seconds to wait for any individual kubernetes operation
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/helm/3.1.2/docs/resources/release#timeout Release#timeout}
    */
    readonly timeout?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/helm/3.1.2/docs/resources/release#timeouts Release#timeouts}
    */
    readonly timeouts?: ReleaseTimeouts;
    /**
    * If true, the provider will install the release at the specified version even if a release not controlled by the provider is present. This is equivalent to running 'helm upgrade --install'. WARNING: this may not be suitable for production use -- see the 'Upgrade Mode' note in the provider documentation. Defaults to `false`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/helm/3.1.2/docs/resources/release#upgrade_install Release#upgrade_install}
    */
    readonly upgradeInstall?: boolean | cdktn.IResolvable;
    /**
    * List of values in raw YAML format to pass to helm
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/helm/3.1.2/docs/resources/release#values Release#values}
    */
    readonly values?: string[];
    /**
    * Verify the package before installing it.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/helm/3.1.2/docs/resources/release#verify Release#verify}
    */
    readonly verify?: boolean | cdktn.IResolvable;
    /**
    * Specify the exact chart version to install. If this is not specified, the latest version is installed
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/helm/3.1.2/docs/resources/release#version Release#version}
    */
    readonly version?: string;
    /**
    * Will wait until all resources are in a ready state before marking the release as successful.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/helm/3.1.2/docs/resources/release#wait Release#wait}
    */
    readonly wait?: boolean | cdktn.IResolvable;
    /**
    * If wait is enabled, will wait until all Jobs have been completed before marking the release as successful.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/helm/3.1.2/docs/resources/release#wait_for_jobs Release#wait_for_jobs}
    */
    readonly waitForJobs?: boolean | cdktn.IResolvable;
}
export interface ReleaseMetadata {
}
export declare function releaseMetadataToTerraform(struct?: ReleaseMetadata): any;
export declare function releaseMetadataToHclTerraform(struct?: ReleaseMetadata): any;
export declare class ReleaseMetadataOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ReleaseMetadata | undefined;
    set internalValue(value: ReleaseMetadata | undefined);
    get appVersion(): string;
    get chart(): string;
    get firstDeployed(): number;
    get lastDeployed(): number;
    get name(): string;
    get namespace(): string;
    get notes(): string;
    get revision(): number;
    get values(): string;
    get version(): string;
}
export interface ReleasePostrender {
    /**
    * An argument to the post-renderer (can specify multiple)
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/helm/3.1.2/docs/resources/release#args Release#args}
    */
    readonly args?: string[];
    /**
    * The common binary path
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/helm/3.1.2/docs/resources/release#binary_path Release#binary_path}
    */
    readonly binaryPath: string;
}
export declare function releasePostrenderToTerraform(struct?: ReleasePostrender | cdktn.IResolvable): any;
export declare function releasePostrenderToHclTerraform(struct?: ReleasePostrender | cdktn.IResolvable): any;
export declare class ReleasePostrenderOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ReleasePostrender | cdktn.IResolvable | undefined;
    set internalValue(value: ReleasePostrender | cdktn.IResolvable | undefined);
    private _args?;
    get args(): string[];
    set args(value: string[]);
    resetArgs(): void;
    get argsInput(): string[] | undefined;
    private _binaryPath?;
    get binaryPath(): string;
    set binaryPath(value: string);
    get binaryPathInput(): string | undefined;
}
export interface ReleaseSet {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/helm/3.1.2/docs/resources/release#name Release#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/helm/3.1.2/docs/resources/release#type Release#type}
    */
    readonly type?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/helm/3.1.2/docs/resources/release#value Release#value}
    */
    readonly value?: string;
}
export declare function releaseSetToTerraform(struct?: ReleaseSet | cdktn.IResolvable): any;
export declare function releaseSetToHclTerraform(struct?: ReleaseSet | cdktn.IResolvable): any;
export declare class ReleaseSetOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ReleaseSet | cdktn.IResolvable | undefined;
    set internalValue(value: ReleaseSet | cdktn.IResolvable | undefined);
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    resetType(): void;
    get typeInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export declare class ReleaseSetList extends cdktn.ComplexList {
    internalValue?: ReleaseSet[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ReleaseSetOutputReference;
}
export interface ReleaseSetListStruct {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/helm/3.1.2/docs/resources/release#name Release#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/helm/3.1.2/docs/resources/release#value Release#value}
    */
    readonly value: string[];
}
export declare function releaseSetListStructToTerraform(struct?: ReleaseSetListStruct | cdktn.IResolvable): any;
export declare function releaseSetListStructToHclTerraform(struct?: ReleaseSetListStruct | cdktn.IResolvable): any;
export declare class ReleaseSetListStructOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ReleaseSetListStruct | cdktn.IResolvable | undefined;
    set internalValue(value: ReleaseSetListStruct | cdktn.IResolvable | undefined);
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _value?;
    get value(): string[];
    set value(value: string[]);
    get valueInput(): string[] | undefined;
}
export declare class ReleaseSetListStructList extends cdktn.ComplexList {
    internalValue?: ReleaseSetListStruct[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ReleaseSetListStructOutputReference;
}
export interface ReleaseSetSensitive {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/helm/3.1.2/docs/resources/release#name Release#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/helm/3.1.2/docs/resources/release#type Release#type}
    */
    readonly type?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/helm/3.1.2/docs/resources/release#value Release#value}
    */
    readonly value: string;
}
export declare function releaseSetSensitiveToTerraform(struct?: ReleaseSetSensitive | cdktn.IResolvable): any;
export declare function releaseSetSensitiveToHclTerraform(struct?: ReleaseSetSensitive | cdktn.IResolvable): any;
export declare class ReleaseSetSensitiveOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ReleaseSetSensitive | cdktn.IResolvable | undefined;
    set internalValue(value: ReleaseSetSensitive | cdktn.IResolvable | undefined);
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    resetType(): void;
    get typeInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    get valueInput(): string | undefined;
}
export declare class ReleaseSetSensitiveList extends cdktn.ComplexList {
    internalValue?: ReleaseSetSensitive[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ReleaseSetSensitiveOutputReference;
}
export interface ReleaseSetWo {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/helm/3.1.2/docs/resources/release#name Release#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/helm/3.1.2/docs/resources/release#type Release#type}
    */
    readonly type?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/helm/3.1.2/docs/resources/release#value Release#value}
    */
    readonly value: string;
}
export declare function releaseSetWoToTerraform(struct?: ReleaseSetWo | cdktn.IResolvable): any;
export declare function releaseSetWoToHclTerraform(struct?: ReleaseSetWo | cdktn.IResolvable): any;
export declare class ReleaseSetWoOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ReleaseSetWo | cdktn.IResolvable | undefined;
    set internalValue(value: ReleaseSetWo | cdktn.IResolvable | undefined);
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    resetType(): void;
    get typeInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    get valueInput(): string | undefined;
}
export declare class ReleaseSetWoList extends cdktn.ComplexList {
    internalValue?: ReleaseSetWo[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ReleaseSetWoOutputReference;
}
export interface ReleaseTimeouts {
    /**
    * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/helm/3.1.2/docs/resources/release#create Release#create}
    */
    readonly create?: string;
    /**
    * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours). Setting a timeout for a Delete operation is only applicable if changes are saved into state before the destroy operation occurs.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/helm/3.1.2/docs/resources/release#delete Release#delete}
    */
    readonly delete?: string;
    /**
    * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours). Read operations occur during any refresh or planning operation when refresh is enabled.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/helm/3.1.2/docs/resources/release#read Release#read}
    */
    readonly read?: string;
    /**
    * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/helm/3.1.2/docs/resources/release#update Release#update}
    */
    readonly update?: string;
}
export declare function releaseTimeoutsToTerraform(struct?: ReleaseTimeouts | cdktn.IResolvable): any;
export declare function releaseTimeoutsToHclTerraform(struct?: ReleaseTimeouts | cdktn.IResolvable): any;
export declare class ReleaseTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ReleaseTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: ReleaseTimeouts | cdktn.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
    private _read?;
    get read(): string;
    set read(value: string);
    resetRead(): void;
    get readInput(): string | undefined;
    private _update?;
    get update(): string;
    set update(value: string);
    resetUpdate(): void;
    get updateInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/helm/3.1.2/docs/resources/release helm_release}
*/
export declare class Release extends cdktn.TerraformResource {
    static readonly tfResourceType = "helm_release";
    /**
    * Generates CDKTN code for importing a Release resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the Release to import
    * @param importFromId The id of the existing Release that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/helm/3.1.2/docs/resources/release#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the Release to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/helm/3.1.2/docs/resources/release helm_release} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ReleaseConfig
    */
    constructor(scope: Construct, id: string, config: ReleaseConfig);
    private _atomic?;
    get atomic(): boolean | cdktn.IResolvable;
    set atomic(value: boolean | cdktn.IResolvable);
    resetAtomic(): void;
    get atomicInput(): boolean | cdktn.IResolvable | undefined;
    private _chart?;
    get chart(): string;
    set chart(value: string);
    get chartInput(): string | undefined;
    private _cleanupOnFail?;
    get cleanupOnFail(): boolean | cdktn.IResolvable;
    set cleanupOnFail(value: boolean | cdktn.IResolvable);
    resetCleanupOnFail(): void;
    get cleanupOnFailInput(): boolean | cdktn.IResolvable | undefined;
    private _createNamespace?;
    get createNamespace(): boolean | cdktn.IResolvable;
    set createNamespace(value: boolean | cdktn.IResolvable);
    resetCreateNamespace(): void;
    get createNamespaceInput(): boolean | cdktn.IResolvable | undefined;
    private _dependencyUpdate?;
    get dependencyUpdate(): boolean | cdktn.IResolvable;
    set dependencyUpdate(value: boolean | cdktn.IResolvable);
    resetDependencyUpdate(): void;
    get dependencyUpdateInput(): boolean | cdktn.IResolvable | undefined;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _devel?;
    get devel(): boolean | cdktn.IResolvable;
    set devel(value: boolean | cdktn.IResolvable);
    resetDevel(): void;
    get develInput(): boolean | cdktn.IResolvable | undefined;
    private _disableCrdHooks?;
    get disableCrdHooks(): boolean | cdktn.IResolvable;
    set disableCrdHooks(value: boolean | cdktn.IResolvable);
    resetDisableCrdHooks(): void;
    get disableCrdHooksInput(): boolean | cdktn.IResolvable | undefined;
    private _disableOpenapiValidation?;
    get disableOpenapiValidation(): boolean | cdktn.IResolvable;
    set disableOpenapiValidation(value: boolean | cdktn.IResolvable);
    resetDisableOpenapiValidation(): void;
    get disableOpenapiValidationInput(): boolean | cdktn.IResolvable | undefined;
    private _disableWebhooks?;
    get disableWebhooks(): boolean | cdktn.IResolvable;
    set disableWebhooks(value: boolean | cdktn.IResolvable);
    resetDisableWebhooks(): void;
    get disableWebhooksInput(): boolean | cdktn.IResolvable | undefined;
    private _forceUpdate?;
    get forceUpdate(): boolean | cdktn.IResolvable;
    set forceUpdate(value: boolean | cdktn.IResolvable);
    resetForceUpdate(): void;
    get forceUpdateInput(): boolean | cdktn.IResolvable | undefined;
    get id(): string;
    private _keyring?;
    get keyring(): string;
    set keyring(value: string);
    resetKeyring(): void;
    get keyringInput(): string | undefined;
    private _lint?;
    get lint(): boolean | cdktn.IResolvable;
    set lint(value: boolean | cdktn.IResolvable);
    resetLint(): void;
    get lintInput(): boolean | cdktn.IResolvable | undefined;
    get manifest(): string;
    private _maxHistory?;
    get maxHistory(): number;
    set maxHistory(value: number);
    resetMaxHistory(): void;
    get maxHistoryInput(): number | undefined;
    private _metadata;
    get metadata(): ReleaseMetadataOutputReference;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _namespace?;
    get namespace(): string;
    set namespace(value: string);
    resetNamespace(): void;
    get namespaceInput(): string | undefined;
    private _passCredentials?;
    get passCredentials(): boolean | cdktn.IResolvable;
    set passCredentials(value: boolean | cdktn.IResolvable);
    resetPassCredentials(): void;
    get passCredentialsInput(): boolean | cdktn.IResolvable | undefined;
    private _postrender;
    get postrender(): ReleasePostrenderOutputReference;
    putPostrender(value: ReleasePostrender): void;
    resetPostrender(): void;
    get postrenderInput(): cdktn.IResolvable | ReleasePostrender | undefined;
    private _recreatePods?;
    get recreatePods(): boolean | cdktn.IResolvable;
    set recreatePods(value: boolean | cdktn.IResolvable);
    resetRecreatePods(): void;
    get recreatePodsInput(): boolean | cdktn.IResolvable | undefined;
    private _renderSubchartNotes?;
    get renderSubchartNotes(): boolean | cdktn.IResolvable;
    set renderSubchartNotes(value: boolean | cdktn.IResolvable);
    resetRenderSubchartNotes(): void;
    get renderSubchartNotesInput(): boolean | cdktn.IResolvable | undefined;
    private _replace?;
    get replace(): boolean | cdktn.IResolvable;
    set replace(value: boolean | cdktn.IResolvable);
    resetReplace(): void;
    get replaceInput(): boolean | cdktn.IResolvable | undefined;
    private _repository?;
    get repository(): string;
    set repository(value: string);
    resetRepository(): void;
    get repositoryInput(): string | undefined;
    private _repositoryCaFile?;
    get repositoryCaFile(): string;
    set repositoryCaFile(value: string);
    resetRepositoryCaFile(): void;
    get repositoryCaFileInput(): string | undefined;
    private _repositoryCertFile?;
    get repositoryCertFile(): string;
    set repositoryCertFile(value: string);
    resetRepositoryCertFile(): void;
    get repositoryCertFileInput(): string | undefined;
    private _repositoryKeyFile?;
    get repositoryKeyFile(): string;
    set repositoryKeyFile(value: string);
    resetRepositoryKeyFile(): void;
    get repositoryKeyFileInput(): string | undefined;
    private _repositoryPassword?;
    get repositoryPassword(): string;
    set repositoryPassword(value: string);
    resetRepositoryPassword(): void;
    get repositoryPasswordInput(): string | undefined;
    private _repositoryUsername?;
    get repositoryUsername(): string;
    set repositoryUsername(value: string);
    resetRepositoryUsername(): void;
    get repositoryUsernameInput(): string | undefined;
    private _resetValues?;
    get resetValues(): boolean | cdktn.IResolvable;
    set resetValues(value: boolean | cdktn.IResolvable);
    resetResetValues(): void;
    get resetValuesInput(): boolean | cdktn.IResolvable | undefined;
    private _resources;
    get resources(): cdktn.StringMap;
    private _reuseValues?;
    get reuseValues(): boolean | cdktn.IResolvable;
    set reuseValues(value: boolean | cdktn.IResolvable);
    resetReuseValues(): void;
    get reuseValuesInput(): boolean | cdktn.IResolvable | undefined;
    private _set;
    get set(): ReleaseSetList;
    putSet(value: ReleaseSet[] | cdktn.IResolvable): void;
    resetSet(): void;
    get setInput(): cdktn.IResolvable | ReleaseSet[] | undefined;
    private _setList;
    get setList(): ReleaseSetListStructList;
    putSetList(value: ReleaseSetListStruct[] | cdktn.IResolvable): void;
    resetSetList(): void;
    get setListInput(): cdktn.IResolvable | ReleaseSetListStruct[] | undefined;
    private _setSensitive;
    get setSensitive(): ReleaseSetSensitiveList;
    putSetSensitive(value: ReleaseSetSensitive[] | cdktn.IResolvable): void;
    resetSetSensitive(): void;
    get setSensitiveInput(): cdktn.IResolvable | ReleaseSetSensitive[] | undefined;
    private _setWo;
    get setWo(): ReleaseSetWoList;
    putSetWo(value: ReleaseSetWo[] | cdktn.IResolvable): void;
    resetSetWo(): void;
    get setWoInput(): cdktn.IResolvable | ReleaseSetWo[] | undefined;
    private _setWoRevision?;
    get setWoRevision(): number;
    set setWoRevision(value: number);
    resetSetWoRevision(): void;
    get setWoRevisionInput(): number | undefined;
    private _skipCrds?;
    get skipCrds(): boolean | cdktn.IResolvable;
    set skipCrds(value: boolean | cdktn.IResolvable);
    resetSkipCrds(): void;
    get skipCrdsInput(): boolean | cdktn.IResolvable | undefined;
    get status(): string;
    private _takeOwnership?;
    get takeOwnership(): boolean | cdktn.IResolvable;
    set takeOwnership(value: boolean | cdktn.IResolvable);
    resetTakeOwnership(): void;
    get takeOwnershipInput(): boolean | cdktn.IResolvable | undefined;
    private _timeout?;
    get timeout(): number;
    set timeout(value: number);
    resetTimeout(): void;
    get timeoutInput(): number | undefined;
    private _timeouts;
    get timeouts(): ReleaseTimeoutsOutputReference;
    putTimeouts(value: ReleaseTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | ReleaseTimeouts | undefined;
    private _upgradeInstall?;
    get upgradeInstall(): boolean | cdktn.IResolvable;
    set upgradeInstall(value: boolean | cdktn.IResolvable);
    resetUpgradeInstall(): void;
    get upgradeInstallInput(): boolean | cdktn.IResolvable | undefined;
    private _values?;
    get values(): string[];
    set values(value: string[]);
    resetTfValues(): void;
    get valuesInput(): string[] | undefined;
    private _verify?;
    get verify(): boolean | cdktn.IResolvable;
    set verify(value: boolean | cdktn.IResolvable);
    resetVerify(): void;
    get verifyInput(): boolean | cdktn.IResolvable | undefined;
    private _version?;
    get version(): string;
    set version(value: string);
    resetVersion(): void;
    get versionInput(): string | undefined;
    private _wait?;
    get wait(): boolean | cdktn.IResolvable;
    set wait(value: boolean | cdktn.IResolvable);
    resetWait(): void;
    get waitInput(): boolean | cdktn.IResolvable | undefined;
    private _waitForJobs?;
    get waitForJobs(): boolean | cdktn.IResolvable;
    set waitForJobs(value: boolean | cdktn.IResolvable);
    resetWaitForJobs(): void;
    get waitForJobsInput(): boolean | cdktn.IResolvable | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
